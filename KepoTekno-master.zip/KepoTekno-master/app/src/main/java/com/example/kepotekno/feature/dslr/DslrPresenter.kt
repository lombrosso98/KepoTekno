package com.example.kepotekno.feature.dslr

import com.example.kepotekno.model.Kamera
import com.google.firebase.database.*

class DslrPresenter(private val view: DslrContract.View)
    : DslrContract.Presenter {

    private val database: FirebaseDatabase = FirebaseDatabase.getInstance()
    private val list: MutableList<Kamera> = mutableListOf()

    override fun getAllKamera() {
        view.showLoading()
        var myRef: DatabaseReference = database.reference.child("kamera")
        myRef.addValueEventListener(object : ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onDataChange(p0: DataSnapshot) {
                list.clear()

                for (dataSnapshot in p0.children) {
                    val data = dataSnapshot.getValue(Kamera::class.java)
                    list.add(data!!)
                }
                view.showAllKamera(list)
                view.hideLoading()
            }

        })
    }
}